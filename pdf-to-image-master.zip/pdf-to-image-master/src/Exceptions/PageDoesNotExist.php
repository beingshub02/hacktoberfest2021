<?php

namespace Spatie\PdfToImage\Exceptions;

use Exception;

class PageDoesNotExist extends Exception
{
}
