<?php

namespace Spatie\PdfToImage\Exceptions;

use Exception;

class PdfDoesNotExist extends Exception
{
}
